Capstone
========

This is my capstone project - it is currently in development and a lot will change. The goal is to design an iPad app to help young children (3-5) learn skills required by programming - like computational thinking