

function loadInstruction1(){
	$("#instr").show();
	setTimeout(function(){$("#instr").hide();}, 5000);
}

function loadInstruction5(){
	$("#instr").attr("src","img/instructions2.gif");
	$("#instr").show();
	setTimeout(function(){$("#instr").hide();}, 5000);
}
